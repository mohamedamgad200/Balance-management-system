﻿namespace alahaly_momken.Entites
{
    public class SuperAdmin
    {
        public int id { get; set; }
        public string name { get; set; } = "super admin";
        public string email { get; set; } = "admin@gmail.com";
        public string password { get; set; } = "admin";
        public String Role { get; set; } = "super admin";

    }
}
