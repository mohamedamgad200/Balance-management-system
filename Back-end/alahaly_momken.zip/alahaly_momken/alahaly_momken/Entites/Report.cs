﻿namespace alahaly_momken.Entites
{
    public class Report
    {
    }
}
